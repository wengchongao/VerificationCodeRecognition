import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from torch.autograd import Variable
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import datetime

# 打开日志文件
def open_log_file(file_name=None):
    file = open('./results/' + file_name, 'w', encoding='utf-8')
    return file

# 关闭日志文件
def close_log_file(file=None):
    file.close()

# 打印日志信息
def log(msg='', file=None, print_msg=True, end='\n'):
    if print_msg:
        print(msg)  # 控制台打印信息

    now = datetime.datetime.now()  # 获取当前时间
    t = str(now.year) + '/' + str(now.month) + '/' + str(now.day) + ' ' \
        + str(now.hour).zfill(2) + ':' + str(now.minute).zfill(2) + ':' + str(now.second).zfill(2)

    if isinstance(msg, str):
        lines = msg.split('\n')
    else:
        lines = [msg]

    for line in lines:
        if line == lines[-1]:
            file.write('[' + t + '] ' + str(line) + end)
        else:
            file.write('[' + t + '] ' + str(line))

# 检查是否有可用的 GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
log_device = f"使用设备: {device}"

# 打开日志文件
file = open_log_file(file_name='ConvNet_with_SA')

# 记录使用的设备
log(log_device, file=file)

# 自定义数据集类
class MyDataset(Dataset):
    def __init__(self, root_dir, label_file, transform=None):
        self.root_dir = root_dir
        self.label = np.loadtxt(label_file)  # 加载验证码的标签
        self.transform = transform

    def __getitem__(self, idx):
        img_name = os.path.join(self.root_dir, '%.4d.jpg' % idx)
        image = Image.open(img_name)

        labels = self.label[idx]

        if self.transform:
            image = self.transform(image)

        return image, labels

    def __len__(self):
        return self.label.shape[0]

# 自注意力模块
class SelfAttention(nn.Module):
    def __init__(self, in_channels):
        super(SelfAttention, self).__init__()
        self.query = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        batch_size, channels, height, width = x.size()

        proj_query = self.query(x).view(batch_size, -1, width * height).permute(0, 2, 1)  # [batch_size, width*height, C//8]
        proj_key = self.key(x).view(batch_size, -1, width * height)  # [batch_size, C//8, width*height]
        proj_value = self.value(x).view(batch_size, -1, width * height)  # [batch_size, C, width*height]

        energy = torch.bmm(proj_query, proj_key)  # [batch_size, width*height, width*height]
        attention = torch.nn.functional.softmax(energy, dim=-1)  # 行方向softmax, [batch_size, width*height, width*height]

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))  # [batch_size, C, width*height]
        out = out.view(batch_size, channels, height, width)

        out = self.gamma * out + x

        return out

# 自定义卷积网络模型（添加自注意力机制）
class ConvNet(nn.Module):
    def __init__(self):
        super(ConvNet, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=4, stride=1, padding=2),  # 验证码的大小为 [3, 60, 160]
            nn.BatchNorm2d(32),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2),  # [batch_size, 32, 30, 80]
            SelfAttention(32),

            nn.Conv2d(32, 64, kernel_size=4, stride=1, padding=2),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2),  # [batch_size, 64, 15, 40]
            SelfAttention(64),

            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2)  # [batch_size, 64, 7, 20]
            # SelfAttention(64)  可选是否加入到最后一层
        )

        self.fc1 = nn.Linear(64 * 7 * 20, 512)
        self.fc2 = nn.Linear(512, 40)  # 每个图片中有4个数字，每个数字为10分类，所以为40个输出

    def forward(self, x):
        x = self.conv(x)  # [batch_size, 64, 7, 20]
        x = x.view(x.size(0), -1)  # [batch_size, 64 * 7 * 20] 或 [batch_size, 8960]
        x = self.fc1(x)  # [batch_size, 512]
        x = F.leaky_relu(x, 0.2)
        x = self.fc2(x)  # [batch_size, 40]
        return x

# 自定义损失函数
def loss_function(output, label):
    loss = nn.CrossEntropyLoss()  # 使用CrossEntropyLoss
    output = output.contiguous().view(-1, 10)  # 将其转化为 [batch_size * 4, 10]
    label = label.contiguous().view(-1)  # [batch_size * 4, ]
    total_loss = loss(output, label)  # 交叉熵
    return total_loss

file_path = './data/image/'  # 验证码图片目录
label_path = './data/label.txt'  # 标签文件
model_path = './checkpoints/best_model.pkl'  # 模型权重文件
batch_size = 128  # 批次大小
epochs = 10  # 迭代轮数
learning_rate = 0.003  # 学习率

# 形成数据集
dataset = MyDataset(file_path, label_path, transform=transforms.ToTensor())

# 形成迭代器
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)

# 数据集大小
dataset_size = len(dataset)

# 定义卷积网络模型并移动到设备
model = ConvNet().to(device)

# 定义优化器
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# 最好模型的权重，以及准确率
best_model = model.state_dict()
best_acc = 0.0

for epoch in range(epochs):
    epoch_acc = 0  # 每个epoch分类准确率
    epoch_count = 0  # 每个epoch正确分类数目
    epoch_loss = 0  # 每个epoch的loss

    if epoch == 0:
        log('【模型结构】', file=file, print_msg=True)
        log(str(model), file=file, print_msg=True)

    for x, y in dataloader:
        # 将数据和标签移动到设备
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        pred = model(x)

        loss = loss_function(pred, y.long())
        epoch_loss += loss.item()

        # 每个batch正确分类数目
        epoch_count += pred.contiguous().view(-1, 10).argmax(axis=1).eq(y.contiguous().view(-1)).sum().item()

        loss.backward()
        optimizer.step()

    epoch_acc = epoch_count / (len(dataloader) * batch_size * 4)  # 每个batch有4个数字
    epoch_loss /= len(dataloader)

    log("【EPOCH: 】%s" % str(epoch + 1), file=file, print_msg=True)
    log("训练损失为：{:.4f}".format(epoch_loss) + '\t' + "训练精度为：{:.4f}".format(epoch_acc), file=file, print_msg=True)

    # 保存最优模型参数
    if epoch_acc > best_acc:
        best_acc = epoch_acc
        best_model = model.state_dict()

    # 在最后一个epoch训练完毕后将模型保存
    if epoch == epochs - 1:
        # 保存模型
        torch.save(best_model, model_path)

log('【Finished Training！】', file=file, print_msg=True)

# 关闭日志文件
close_log_file(file)
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms

img_path = r'./test/image/0000.jpg'  # 测试验证码图片

# 打开并调整图片大小
img = Image.open(img_path).resize((160, 60), Image.LANCZOS)

# 将其转换成tensor
img = transforms.ToTensor()(img)

# 处理成模型输入格式 [batch_size, 3, 60, 160]
img = torch.unsqueeze(img, dim=0)

# 自定义卷积网络模型
class SelfAttention(nn.Module):
    def __init__(self, in_dim):
        super(SelfAttention, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.softmax = nn.Softmax(dim=-1)  # 对最后一个维度进行softmax操作

    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X W X H)
            returns :
                out : self attention value + input feature
                attention: B X N X N (N是width*height)
        """
        m_batchsize, C, width, height = x.size()
        proj_query = self.query_conv(x).view(m_batchsize, -1, width * height).permute(0, 2, 1)  # B X N X C'
        proj_key = self.key_conv(x).view(m_batchsize, -1, width * height)  # B X C' X N
        energy = torch.bmm(proj_query, proj_key)  # B X N X N
        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(m_batchsize, -1, width * height)

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(m_batchsize, C, width, height)

        out = self.gamma * out + x

        return out

# 自定义卷积网络模型
class ConvNet(nn.Module):
    def __init__(self):
        super(ConvNet, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2),

            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2),

            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2),

            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),  # 增加卷积层
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.MaxPool2d(kernel_size=2)  # [batch_size, 256, 3, 10]
        )

        self.attention = SelfAttention(256)  # 更新自注意力机制的输入维度

        self.fc1 = nn.Linear(256 * 3 * 10, 2048)  # 更新全连接层的输入维度
        self.fc2 = nn.Linear(2048, 1024)
        self.fc3 = nn.Linear(1024, 40)  # 每个图片中有4个数字，每个数字为10分类，所以为40个输出

        self.dropout = nn.Dropout(0.5)  # 减少dropout率以增加模型的复杂度

    def forward(self, x):
        x = self.conv(x)  # [batch_size, 256, 3, 10]
        x = self.attention(x)  # [batch_size, 256, 3, 10]
        x = x.view(x.size(0), -1)  # [batch_size, 256 * 3 * 10]
        x = self.fc1(x)  # [batch_size, 2048]
        x = F.leaky_relu(x, 0.2)
        x = self.dropout(x)
        x = self.fc2(x)  # [batch_size, 1024]
        x = F.leaky_relu(x, 0.2)
        x = self.dropout(x)
        x = self.fc3(x)  # [batch_size, 40]

        return x

# 加载模型权重
model = ConvNet()
model.load_state_dict(torch.load('./checkpoints/best_model.pkl'))

# 设置模型为评估模式
model.eval()

# 验证码识别
with torch.no_grad():
    pred = model(img)
    predict_captcha = pred.contiguous().view(-1, 10).argmax(axis=1).numpy().tolist()

print('验证码: ', predict_captcha)